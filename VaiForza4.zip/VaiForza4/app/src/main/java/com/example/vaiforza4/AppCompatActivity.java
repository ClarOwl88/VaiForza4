package com.example.vaiforza4;

public class AppCompatActivity {
}
