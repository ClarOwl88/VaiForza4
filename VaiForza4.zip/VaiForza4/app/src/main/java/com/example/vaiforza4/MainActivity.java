package com.example.vaiforza4;

import android.os.Bundle;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.os.Handler;
import android.media.MediaPlayer;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private final Button[][] buttons = new Button[6][7];
    private boolean player1 = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for (int i = 0; i < 6; i++) {
            {
                String buttonID = "button" + i + 0;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][0] = findViewById(resID);
                buttons[i][0].setOnClickListener(this);
            }
            {
                String buttonID = "button" + i + 1;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][1] = findViewById(resID);
                buttons[i][1].setOnClickListener(this);
            }
            {
                String buttonID = "button" + i + 2;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][2] = findViewById(resID);
                buttons[i][2].setOnClickListener(this);
            }
            {
                String buttonID = "button" + i + 3;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][3] = findViewById(resID);
                buttons[i][3].setOnClickListener(this);
            }
            {
                String buttonID = "button" + i + 4;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][4] = findViewById(resID);
                buttons[i][4].setOnClickListener(this);
            }
            {
                String buttonID = "button" + i + 5;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][5] = findViewById(resID);
                buttons[i][5].setOnClickListener(this);
            }
            {
                String buttonID = "button" + i + 6;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][6] = findViewById(resID);
                buttons[i][6].setOnClickListener(this);
            }
        }

        TextView playerTurn = findViewById(R.id.playerTurn);

        Button resetButton;
        resetButton = findViewById(R.id.Reset);
        resetButton.setOnClickListener(v -> ResetTable());
    }


    @Override
    public void onClick(View v) {
        int line = -1;
        int column = -1;
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                if (v == buttons[i][j]) {
                    line = i;
                    column = j;
                    break;
                }
            }
        }
        if (line == -1 || column == -1) {
            return;
        }

        int EmptyLine = -1;
        for (int i = 5; i >= 0; i--) {
            if (buttons[i][column].getText().toString().equals("*")) {
                EmptyLine = i;
                break;
            }
        }

        if (EmptyLine == -1) {
            Toast.makeText(this, "Spazio esaurito!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (player1) {
            buttons[EmptyLine][column].setText("X");
            TextView t=(TextView)findViewById(R.id.playerTurn);
            t.setText("Turno: Giocatore 1");
            playerTurn();

        } else {
            buttons[EmptyLine][column].setText("O");
            TextView t=(TextView)findViewById(R.id.playerTurn);
            t.setText("Turno: Giocatore 2");
            playerTurn();
        }

        if (VictoryCheck(EmptyLine, column)) {
            String winner = player1 ? "Giocatore 1" : "Giocatore 2";
            Toast.makeText(this, winner + " vince ! 🎉", Toast.LENGTH_SHORT).show();
            ResetTable();
        } else if (DrawCheck()) {
            Toast.makeText(this, "Pareggio!", Toast.LENGTH_SHORT).show();
            ResetTable();
        } else {
            player1 = !player1;
        }
    }

    private boolean VictoryCheck(int EmptyLine, int column) {
        for (int j = 0; j <= 3; j++) {
            if (buttons[EmptyLine][j].getText().equals(buttons[EmptyLine][j + 1].getText()) &&
                    buttons[EmptyLine][j].getText().equals(buttons[EmptyLine][j + 2].getText()) &&
                    buttons[EmptyLine][j].getText().equals(buttons[EmptyLine][j + 3].getText()) &&
                    !buttons[EmptyLine][j].getText().equals("*")) {
                return true;
            }
        }

        for(int i = 0; i <=2;i++) {
            if (buttons[i][column].getText().equals(buttons[i + 1][column].getText()) &&
                buttons[i][column].getText().equals(buttons[i + 2][column].getText()) &&
                buttons[i][column].getText().equals(buttons[i + 3][column].getText()) &&
                !buttons[i][column].getText().equals("*")) {
                return true;
            }
        }
        for(int i = 0; i <=2;i++) {
            for (int j = 0; j <= 3; j++) {
                if (buttons[i][j].getText().equals(buttons[i + 1][j + 1].getText()) &&
                    buttons[i][j].getText().equals(buttons[i + 2][j + 2].getText()) &&
                    buttons[i][j].getText().equals(buttons[i + 3][j + 3].getText()) &&
                    !buttons[i][j].getText().equals("*")) {
                return true;
                }
            }
        }
        for(int i = 0; i <=2;i++) {
            for (int j = 6; j >= 3; j--) {
                if (buttons[i][j].getText().equals(buttons[i + 1][j - 1].getText()) &&
                    buttons[i][j].getText().equals(buttons[i + 2][j - 2].getText()) &&
                    buttons[i][j].getText().equals(buttons[i + 3][j - 3].getText()) &&
                    !buttons[i][j].getText().equals("*")) {
                return true;
                }
            }

        }
        return false;
    }
    private boolean DrawCheck () {
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                if (buttons[i][j].getText().equals("*")) {
                    return false;
                }
            }
        }
        return true;
    }
    private void ChangePlayerTurn () {
        TextView PlayerTurn = findViewById(R.id.playerTurn);
        PlayerTurn.setText(player1 ? "Turno: Giocatore 2" : "Turno: Giocatore 1");
    }

    private void ResetTable () {
        new Handler().postDelayed(() -> {
            for (int i = 0; i < 6; i++) {
                for (int j = 0; j < 7; j++) {
                    buttons[i][j].setText("*");
                }
            }
            player1 = false;
            ChangePlayerTurn();
            player1 = true;
        }, 500);
    }

    private void playerTurn() {
    }
}

